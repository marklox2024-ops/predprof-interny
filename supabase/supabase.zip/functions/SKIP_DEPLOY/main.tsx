# DO NOT DEPLOY
# This function directory should be ignored
# See /supabase/config.toml - functions.enabled = false
